export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  description: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  featured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface RaffleEntry {
  id: string;
  userId: string;
  month: string;
  year: number;
  chances: number;
  isActive: boolean;
  paymentDate: Date;
}

export interface RaffleUser {
  id: string;
  name: string;
  email: string;
  totalChances: number;
  monthsWithoutWinning: number;
  hasDiscount: boolean;
  lastWinDate?: Date;
  consolationPrizeEligible: boolean;
  bonusPoints: number;
}

export interface RafflePrize {
  id: string;
  name: string;
  description: string;
  image: string;
  value: number;
  type: 'main' | 'secondary' | 'consolation' | 'surprise';
  month: string;
  year: number;
}

export interface RaffleResult {
  id: string;
  month: string;
  year: number;
  mainWinner: RaffleUser;
  secondaryWinners: RaffleUser[];
  consolationWinners: RaffleUser[];
  surpriseWinner?: RaffleUser;
  drawDate: Date;
}