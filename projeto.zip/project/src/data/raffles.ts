import { RafflePrize, RaffleUser, RaffleResult } from '../types';

export const currentRafflePrizes: RafflePrize[] = [
  {
    id: 'main-jan-2024',
    name: 'iPhone 15 Pro Max',
    description: 'Smartphone Apple iPhone 15 Pro Max 256GB',
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=500',
    value: 8999.00,
    type: 'main',
    month: 'Janeiro',
    year: 2024
  },
  {
    id: 'secondary-jan-2024',
    name: 'Cupom de R$ 50',
    description: 'Vale-compras de R$ 50 para usar na loja',
    image: 'https://images.pexels.com/photos/6292/red-gift-box.jpg?auto=compress&cs=tinysrgb&w=500',
    value: 50.00,
    type: 'secondary',
    month: 'Janeiro',
    year: 2024
  },
  {
    id: 'consolation-jan-2024',
    name: 'Kit Caverna Exclusivo',
    description: 'Camiseta + Boné + Adesivos da Caverna Loja',
    image: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=500',
    value: 150.00,
    type: 'consolation',
    month: 'Janeiro',
    year: 2024
  }
];

export const mockRaffleUsers: RaffleUser[] = [
  {
    id: '1',
    name: 'João Silva',
    email: 'joao@email.com',
    totalChances: 5,
    monthsWithoutWinning: 2,
    hasDiscount: true,
    consolationPrizeEligible: false,
    bonusPoints: 10
  },
  {
    id: '2',
    name: 'Maria Santos',
    email: 'maria@email.com',
    totalChances: 8,
    monthsWithoutWinning: 3,
    hasDiscount: true,
    consolationPrizeEligible: true,
    bonusPoints: 15
  },
  {
    id: '3',
    name: 'Pedro Costa',
    email: 'pedro@email.com',
    totalChances: 3,
    monthsWithoutWinning: 1,
    hasDiscount: true,
    consolationPrizeEligible: false,
    bonusPoints: 5
  }
];

export const previousRaffleResults: RaffleResult[] = [
  {
    id: 'dec-2023',
    month: 'Dezembro',
    year: 2023,
    mainWinner: {
      id: '4',
      name: 'Ana Oliveira',
      email: 'ana@email.com',
      totalChances: 6,
      monthsWithoutWinning: 0,
      hasDiscount: false,
      consolationPrizeEligible: false,
      bonusPoints: 0
    },
    secondaryWinners: [
      {
        id: '5',
        name: 'Carlos Lima',
        email: 'carlos@email.com',
        totalChances: 4,
        monthsWithoutWinning: 0,
        hasDiscount: false,
        consolationPrizeEligible: false,
        bonusPoints: 0
      }
    ],
    consolationWinners: [
      {
        id: '6',
        name: 'Lucia Ferreira',
        email: 'lucia@email.com',
        totalChances: 2,
        monthsWithoutWinning: 0,
        hasDiscount: false,
        consolationPrizeEligible: false,
        bonusPoints: 0
      }
    ],
    drawDate: new Date('2023-12-31')
  }
];

export const raffleStats = {
  totalParticipants: 247,
  totalPrizesGiven: 156,
  currentMonthRevenue: 4940, // 247 * 20
  averageChancesPerUser: 4.2,
  satisfactionRate: 94
};