import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Camiseta Caverna Premium',
    price: 89.90,
    originalPrice: 129.90,
    image: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Roupas',
    description: 'Camiseta premium com design exclusivo da Caverna Loja. Tecido 100% algodão com estampa de alta qualidade.',
    rating: 4.8,
    reviews: 124,
    inStock: true,
    featured: true
  },
  {
    id: '2',
    name: 'Moletom Caverna Black',
    price: 159.90,
    originalPrice: 199.90,
    image: 'https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Roupas',
    description: 'Moletom preto com capuz e logo bordado. Perfeito para o inverno com máximo conforto.',
    rating: 4.9,
    reviews: 89,
    inStock: true,
    featured: true
  },
  {
    id: '3',
    name: 'Boné Caverna Snapback',
    price: 69.90,
    image: 'https://images.pexels.com/photos/1124465/pexels-photo-1124465.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Acessórios',
    description: 'Boné snapback com bordado 3D do logo. Aba reta e ajuste perfeito.',
    rating: 4.7,
    reviews: 156,
    inStock: true
  },
  {
    id: '4',
    name: 'Tênis Caverna Street',
    price: 299.90,
    originalPrice: 399.90,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Calçados',
    description: 'Tênis urbano com design moderno e confortável. Ideal para o dia a dia.',
    rating: 4.6,
    reviews: 78,
    inStock: true,
    featured: true
  },
  {
    id: '5',
    name: 'Jaqueta Caverna Bomber',
    price: 249.90,
    image: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Roupas',
    description: 'Jaqueta bomber com detalhes únicos. Estilo urbano e moderno.',
    rating: 4.8,
    reviews: 92,
    inStock: true
  },
  {
    id: '6',
    name: 'Mochila Caverna Urban',
    price: 179.90,
    image: 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Acessórios',
    description: 'Mochila urbana com compartimentos organizadores. Resistente e estilosa.',
    rating: 4.5,
    reviews: 134,
    inStock: true
  }
];

export const categories = [
  'Todos',
  'Roupas',
  'Acessórios',
  'Calçados'
];