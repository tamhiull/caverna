import React, { useState } from 'react';
import { CreditCard, Gift, Star, CheckCircle, X } from 'lucide-react';

interface RaffleSubscriptionProps {
  isOpen: boolean;
  onClose: () => void;
}

const RaffleSubscription: React.FC<RaffleSubscriptionProps> = ({ isOpen, onClose }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 3000));

    setIsProcessing(false);
    setIsSuccess(true);

    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 3000);
  };

  if (!isOpen) return null;

  if (isSuccess) {
    return (
      <div className="fixed inset-0 z-60 flex items-center justify-center">
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4 text-center relative z-10">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Inscrição Confirmada!</h2>
          <p className="text-gray-600 mb-4">
            Parabéns! Você está participando da rifa de Janeiro 2024. 
            Seu desconto de 5% já está ativo!
          </p>
          <div className="bg-green-50 rounded-lg p-4">
            <p className="text-sm text-green-800 font-semibold">Próximo sorteio: 31 de Janeiro às 20h</p>
            <p className="text-sm text-green-600">Acompanhe pelo nosso Instagram</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-60 overflow-y-auto">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto relative">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-xl">
            <div className="flex items-center space-x-2">
              <Gift className="w-6 h-6" />
              <h2 className="text-xl font-semibold">Participar da Rifa - R$ 20/mês</h2>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Benefits Reminder */}
            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg p-4 border border-yellow-200">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                <Star className="w-5 h-5 text-yellow-500" />
                <span>Seus Benefícios</span>
              </h3>
              <div className="grid md:grid-cols-2 gap-3 text-sm">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Concorre a prêmios mensais</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>5% desconto em todas as compras</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>+1 chance a cada mês sem ganhar</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Prêmios de consolação</span>
                </div>
              </div>
            </div>

            {/* Personal Information */}
            <div>
              <h3 className="font-semibold mb-3">Informações Pessoais</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <input
                  type="text"
                  name="name"
                  placeholder="Nome completo"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <input
                type="tel"
                name="phone"
                placeholder="Telefone/WhatsApp"
                value={formData.phone}
                onChange={handleInputChange}
                required
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent mt-4"
              />
            </div>

            {/* Payment Information */}
            <div>
              <h3 className="font-semibold mb-3 flex items-center space-x-2">
                <CreditCard className="w-5 h-5" />
                <span>Informações de Pagamento</span>
              </h3>
              <div className="space-y-4">
                <input
                  type="text"
                  name="cardName"
                  placeholder="Nome no cartão"
                  value={formData.cardName}
                  onChange={handleInputChange}
                  required
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
                <input
                  type="text"
                  name="cardNumber"
                  placeholder="Número do cartão"
                  value={formData.cardNumber}
                  onChange={handleInputChange}
                  required
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    name="expiryDate"
                    placeholder="MM/AA"
                    value={formData.expiryDate}
                    onChange={handleInputChange}
                    required
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                  <input
                    type="text"
                    name="cvv"
                    placeholder="CVV"
                    value={formData.cvv}
                    onChange={handleInputChange}
                    required
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Subscription Details */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-2">Detalhes da Assinatura</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex justify-between">
                  <span>Valor mensal:</span>
                  <span className="font-semibold">R$ 20,00</span>
                </div>
                <div className="flex justify-between">
                  <span>Cobrança:</span>
                  <span>Todo dia 1º do mês</span>
                </div>
                <div className="flex justify-between">
                  <span>Cancelamento:</span>
                  <span>A qualquer momento</span>
                </div>
              </div>
            </div>

            {/* Terms */}
            <div className="flex items-start space-x-2">
              <input
                type="checkbox"
                id="terms"
                required
                className="mt-1 w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
              />
              <label htmlFor="terms" className="text-sm text-gray-600">
                Concordo com os <a href="#" className="text-purple-600 hover:underline">termos e condições</a> e 
                autorizo a cobrança mensal recorrente de R$ 20,00 no meu cartão de crédito.
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-4 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Processando...</span>
                </>
              ) : (
                <>
                  <Gift className="w-5 h-5" />
                  <span>Confirmar Participação - R$ 20/mês</span>
                </>
              )}
            </button>

            <p className="text-xs text-gray-500 text-center">
              Pagamento seguro processado via Stripe. Seus dados estão protegidos.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RaffleSubscription;