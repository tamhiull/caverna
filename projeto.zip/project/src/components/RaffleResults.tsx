import React from 'react';
import { Trophy, Gift, Calendar, Users, Star } from 'lucide-react';
import { previousRaffleResults } from '../data/raffles';

const RaffleResults: React.FC = () => {
  return (
    <section className="bg-white py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Resultados Anteriores
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Confira os ganhadores dos sorteios passados e veja que você pode ser o próximo!
          </p>
        </div>

        <div className="space-y-8">
          {previousRaffleResults.map((result) => (
            <div key={result.id} className="bg-gray-50 rounded-2xl p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <Calendar className="w-6 h-6 text-blue-600" />
                  <h3 className="text-2xl font-bold text-gray-900">
                    {result.month} {result.year}
                  </h3>
                </div>
                <div className="text-sm text-gray-500">
                  Sorteio realizado em {result.drawDate.toLocaleDateString('pt-BR')}
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                {/* Main Winner */}
                <div className="bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl p-6 text-white">
                  <div className="flex items-center space-x-2 mb-4">
                    <Trophy className="w-6 h-6" />
                    <span className="font-semibold">Prêmio Principal</span>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                      <Users className="w-8 h-8" />
                    </div>
                    <h4 className="font-bold text-lg">{result.mainWinner.name}</h4>
                    <p className="text-yellow-100 text-sm">Ganhador do prêmio principal</p>
                  </div>
                </div>

                {/* Secondary Winners */}
                <div className="bg-white rounded-xl p-6 border-2 border-blue-200">
                  <div className="flex items-center space-x-2 mb-4">
                    <Gift className="w-6 h-6 text-blue-600" />
                    <span className="font-semibold text-gray-900">Prêmios Secundários</span>
                  </div>
                  
                  <div className="space-y-3">
                    {result.secondaryWinners.slice(0, 3).map((winner, index) => (
                      <div key={winner.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-blue-600 font-bold text-sm">{index + 1}</span>
                        </div>
                        <span className="text-gray-700 text-sm">{winner.name}</span>
                      </div>
                    ))}
                    {result.secondaryWinners.length > 3 && (
                      <p className="text-gray-500 text-sm">
                        +{result.secondaryWinners.length - 3} outros ganhadores
                      </p>
                    )}
                  </div>
                </div>

                {/* Consolation Winners */}
                <div className="bg-white rounded-xl p-6 border-2 border-green-200">
                  <div className="flex items-center space-x-2 mb-4">
                    <Star className="w-6 h-6 text-green-600" />
                    <span className="font-semibold text-gray-900">Prêmios de Consolação</span>
                  </div>
                  
                  <div className="space-y-3">
                    {result.consolationWinners.map((winner, index) => (
                      <div key={winner.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Gift className="w-4 h-4 text-green-600" />
                        </div>
                        <span className="text-gray-700 text-sm">{winner.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Surprise Winner */}
              {result.surpriseWinner && (
                <div className="mt-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl p-4 text-white">
                  <div className="flex items-center justify-center space-x-2">
                    <Star className="w-5 h-5" />
                    <span className="font-semibold">Sorteio Surpresa:</span>
                    <span className="font-bold">{result.surpriseWinner.name}</span>
                    <span>ganhou frete grátis por 1 ano!</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Seja o Próximo Ganhador!</h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Junte-se aos nossos ganhadores e concorra a prêmios incríveis todos os meses. 
              Quanto mais tempo participar, maiores suas chances!
            </p>
            <button className="bg-white text-blue-600 px-8 py-3 rounded-xl font-bold hover:bg-gray-100 transition-colors">
              Participar da Próxima Rifa
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RaffleResults;