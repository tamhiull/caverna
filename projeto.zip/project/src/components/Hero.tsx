import React from 'react';
import { ArrowRight, Star } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white overflow-hidden">
      <div className="absolute inset-0 bg-black opacity-50"></div>
      
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white via-transparent to-transparent"></div>
      </div>

      <div className="relative container mx-auto px-4 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-yellow-400">
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
                <span className="text-sm font-medium">Avaliação 5.0 (2.5k+ reviews)</span>
              </div>
              
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Estilo Urbano
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-300">
                  Autêntico
                </span>
              </h1>
              
              <p className="text-xl text-gray-300 max-w-lg">
                Descubra a coleção exclusiva da Caverna Loja. Roupas e acessórios que definem seu estilo único na cidade.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-white text-black px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
                <span>Explorar Coleção</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              
              <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-black transition-all duration-300">
                Ver Ofertas
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-gray-700">
              <div>
                <div className="text-2xl font-bold">50k+</div>
                <div className="text-gray-400 text-sm">Clientes Satisfeitos</div>
              </div>
              <div>
                <div className="text-2xl font-bold">500+</div>
                <div className="text-gray-400 text-sm">Produtos Únicos</div>
              </div>
              <div>
                <div className="text-2xl font-bold">99%</div>
                <div className="text-gray-400 text-sm">Satisfação</div>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative z-10">
              <img 
                src="https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Coleção Caverna"
                className="rounded-2xl shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500"
              />
            </div>
            
            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 bg-yellow-400 text-black px-4 py-2 rounded-full font-bold text-sm transform rotate-12 shadow-lg">
              Novo!
            </div>
            
            <div className="absolute -bottom-4 -left-4 bg-red-500 text-white px-4 py-2 rounded-full font-bold text-sm transform -rotate-12 shadow-lg">
              -30% OFF
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;