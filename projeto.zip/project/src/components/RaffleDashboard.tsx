import React, { useState } from 'react';
import { Trophy, Gift, Star, Calendar, Users, TrendingUp, Award, Zap } from 'lucide-react';
import { mockRaffleUsers, currentRafflePrizes, raffleStats } from '../data/raffles';

const RaffleDashboard: React.FC = () => {
  const [selectedUser] = useState(mockRaffleUsers[0]); // Simulating logged user
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  const getNextBonusMessage = (user: typeof selectedUser) => {
    const pointsToNext = 20 - (user.bonusPoints % 20);
    return `Você está a apenas ${pointsToNext} pontos de ganhar um bônus secreto!`;
  };

  return (
    <section className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Seu Dashboard de Rifas
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Acompanhe suas chances, pontos acumulados e próximos sorteios
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* User Stats */}
          <div className="lg:col-span-2 space-y-6">
            {/* Main Stats Cards */}
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-yellow-500">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm font-medium">Suas Chances</p>
                    <p className="text-3xl font-bold text-gray-900">{selectedUser.totalChances}</p>
                  </div>
                  <div className="bg-yellow-100 p-3 rounded-full">
                    <Star className="w-6 h-6 text-yellow-600" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center text-green-600 text-sm">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    <span>+{selectedUser.monthsWithoutWinning} este mês</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-purple-500">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm font-medium">Pontos Bônus</p>
                    <p className="text-3xl font-bold text-gray-900">{selectedUser.bonusPoints}</p>
                  </div>
                  <div className="bg-purple-100 p-3 rounded-full">
                    <Zap className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="bg-purple-100 rounded-full h-2">
                    <div 
                      className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(selectedUser.bonusPoints % 20) * 5}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Próximo bônus em {20 - (selectedUser.bonusPoints % 20)} pontos</p>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-green-500">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm font-medium">Desconto Ativo</p>
                    <p className="text-3xl font-bold text-green-600">5%</p>
                  </div>
                  <div className="bg-green-100 p-3 rounded-full">
                    <Gift className="w-6 h-6 text-green-600" />
                  </div>
                </div>
                <div className="mt-4">
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                    Válido até 31/01
                  </span>
                </div>
              </div>
            </div>

            {/* Engagement Message */}
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
              <div className="flex items-center space-x-3 mb-3">
                <Award className="w-6 h-6" />
                <h3 className="text-lg font-semibold">Mensagem Motivacional</h3>
              </div>
              <p className="text-blue-100 mb-4">{getNextBonusMessage(selectedUser)}</p>
              
              {selectedUser.consolationPrizeEligible && (
                <div className="bg-white/20 rounded-lg p-4 mt-4">
                  <div className="flex items-center space-x-2 text-yellow-300">
                    <Trophy className="w-5 h-5" />
                    <span className="font-semibold">Prêmio de Consolação Disponível!</span>
                  </div>
                  <p className="text-sm text-blue-100 mt-1">
                    Você não ganhou nos últimos 3 meses. Clique para resgatar seu brinde especial!
                  </p>
                </div>
              )}
            </div>

            {/* Monthly Progress */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>Progresso Mensal</span>
              </h3>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Meses sem ganhar:</span>
                  <span className="font-semibold text-gray-900">{selectedUser.monthsWithoutWinning}</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Chances acumuladas:</span>
                  <span className="font-semibold text-yellow-600">+{selectedUser.monthsWithoutWinning}</span>
                </div>
                
                <div className="bg-gray-100 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-yellow-400 to-orange-500 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min((selectedUser.monthsWithoutWinning / 6) * 100, 100)}%` }}
                  ></div>
                </div>
                
                <p className="text-sm text-gray-500">
                  {selectedUser.monthsWithoutWinning < 3 
                    ? `Mais ${3 - selectedUser.monthsWithoutWinning} mês(es) para prêmio de consolação`
                    : 'Elegível para prêmio de consolação!'
                  }
                </p>
              </div>
            </div>
          </div>

          {/* Current Prizes */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <span>Prêmios Janeiro 2024</span>
              </h3>
              
              <div className="space-y-4">
                {currentRafflePrizes.map((prize) => (
                  <div key={prize.id} className="border rounded-lg p-4">
                    <div className="flex items-center space-x-3">
                      <img 
                        src={prize.image} 
                        alt={prize.name}
                        className="w-12 h-12 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{prize.name}</h4>
                        <p className="text-sm text-gray-600">{prize.description}</p>
                        <p className="text-sm font-semibold text-green-600">
                          {formatPrice(prize.value)}
                        </p>
                      </div>
                    </div>
                    
                    {prize.type === 'main' && (
                      <div className="mt-3 bg-yellow-50 rounded-lg p-2">
                        <p className="text-xs text-yellow-800 font-medium">
                          🏆 Prêmio Principal - 1 Ganhador
                        </p>
                      </div>
                    )}
                    
                    {prize.type === 'secondary' && (
                      <div className="mt-3 bg-blue-50 rounded-lg p-2">
                        <p className="text-xs text-blue-800 font-medium">
                          🎁 10 Ganhadores
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Next Draw */}
            <div className="bg-gradient-to-br from-gray-900 to-black rounded-xl p-6 text-white">
              <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>Próximo Sorteio</span>
              </h3>
              
              <div className="text-center">
                <p className="text-3xl font-bold text-yellow-400 mb-2">31 JAN</p>
                <p className="text-gray-300 mb-4">20:00 - Ao vivo no Instagram</p>
                
                <div className="bg-white/10 rounded-lg p-3">
                  <p className="text-sm text-gray-300">Participantes confirmados:</p>
                  <p className="text-2xl font-bold text-white">{raffleStats.totalParticipants}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RaffleDashboard;