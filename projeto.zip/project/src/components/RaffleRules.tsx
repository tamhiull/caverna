import React from 'react';
import { CheckCircle, AlertCircle, Gift, Calendar, Trophy, Star } from 'lucide-react';

const RaffleRules: React.FC = () => {
  return (
    <section className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Como Funciona Nossa Rifa
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Sistema transparente e justo com múltiplas formas de ganhar
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* How it Works */}
          <div className="space-y-8">
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
                <Gift className="w-6 h-6 text-blue-600" />
                <span>Modelo de Negócio</span>
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Participação Mensal</p>
                    <p className="text-gray-600 text-sm">Pague apenas R$ 20/mês para participar de todos os sorteios</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Prêmio Principal</p>
                    <p className="text-gray-600 text-sm">1 produto de alto valor (ex: smartphone, notebook)</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Prêmios Secundários</p>
                    <p className="text-gray-600 text-sm">10 ganhadores de cupons de R$ 50 cada</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
                <Star className="w-6 h-6 text-yellow-500" />
                <span>Sistema de Engajamento</span>
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-5 h-5 bg-yellow-500 rounded-full mt-1 flex-shrink-0 flex items-center justify-center">
                    <span className="text-white text-xs font-bold">+1</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Pontos Acumulativos</p>
                    <p className="text-gray-600 text-sm">A cada mês sem ganhar, você recebe +1 chance no próximo sorteio</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-5 h-5 bg-green-500 rounded-full mt-1 flex-shrink-0 flex items-center justify-center">
                    <span className="text-white text-xs font-bold">5%</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Desconto Imediato</p>
                    <p className="text-gray-600 text-sm">Todos os participantes ganham 5% de desconto nas compras</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Benefits & Rules */}
          <div className="space-y-8">
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
                <Trophy className="w-6 h-6 text-purple-600" />
                <span>Redução de Frustração</span>
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Gift className="w-5 h-5 text-purple-500 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Prêmio de Consolação</p>
                    <p className="text-gray-600 text-sm">Quem não ganha em 3 meses seguidos recebe um brinde especial</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Star className="w-5 h-5 text-purple-500 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Sorteio Surpresa</p>
                    <p className="text-gray-600 text-sm">Mensalmente, um participante aleatório ganha um bônus (frete grátis, desconto extra)</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
                <Calendar className="w-6 h-6 text-blue-600" />
                <span>Cronograma</span>
              </h3>
              
              <div className="space-y-4">
                <div className="border-l-4 border-blue-500 pl-4">
                  <p className="font-semibold text-gray-900">Todo dia 1º</p>
                  <p className="text-gray-600 text-sm">Abertura das inscrições para o mês</p>
                </div>
                
                <div className="border-l-4 border-yellow-500 pl-4">
                  <p className="font-semibold text-gray-900">Todo dia 25</p>
                  <p className="text-gray-600 text-sm">Encerramento das inscrições</p>
                </div>
                
                <div className="border-l-4 border-green-500 pl-4">
                  <p className="font-semibold text-gray-900">Último dia do mês</p>
                  <p className="text-gray-600 text-sm">Sorteio ao vivo no Instagram às 20h</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500 to-blue-500 rounded-xl p-6 text-white">
              <h3 className="text-lg font-bold mb-4">Garantia de Rentabilidade</h3>
              <div className="space-y-2 text-sm">
                <p>• 100 participantes × R$ 20 = R$ 2.000/mês</p>
                <p>• Custo prêmio principal: R$ 1.000</p>
                <p>• Custo prêmios secundários: R$ 500</p>
                <p>• <span className="font-bold">Lucro líquido: R$ 500/mês</span></p>
              </div>
              <p className="text-green-100 text-xs mt-3">
                + Aumento nas vendas devido aos descontos e engajamento
              </p>
            </div>
          </div>
        </div>

        {/* Important Notes */}
        <div className="mt-12 bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-6 h-6 text-yellow-600 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-bold text-yellow-800 mb-2">Informações Importantes</h4>
              <ul className="text-yellow-700 text-sm space-y-1">
                <li>• Sorteios realizados de forma transparente e ao vivo</li>
                <li>• Participação limitada a maiores de 18 anos</li>
                <li>• Prêmios entregues em até 15 dias úteis</li>
                <li>• Cancelamento da participação pode ser feito a qualquer momento</li>
                <li>• Regulamento completo disponível em nosso site</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RaffleRules;