import React from 'react';
import { Gift, Trophy, Star, Users, Calendar, Zap } from 'lucide-react';
import { currentRafflePrizes, raffleStats } from '../data/raffles';

const RaffleHero: React.FC = () => {
  const mainPrize = currentRafflePrizes.find(prize => prize.type === 'main');
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  return (
    <section className="relative bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
      <div className="absolute inset-0 bg-black opacity-30"></div>
      
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-400 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-pink-400 rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-400 rounded-full opacity-20 animate-ping"></div>
      </div>

      <div className="relative container mx-auto px-4 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-yellow-400">
                <Gift className="w-6 h-6" />
                <span className="text-sm font-bold uppercase tracking-wider">Rifa Mensal Caverna</span>
              </div>
              
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Participe e
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-400">
                  Ganhe Prêmios
                </span>
                <span className="block text-2xl lg:text-3xl text-gray-300 mt-2">
                  Incríveis!
                </span>
              </h1>
              
              <p className="text-xl text-gray-300 max-w-lg">
                Por apenas <span className="font-bold text-yellow-400">R$ 20/mês</span>, 
                você concorre a prêmios fantásticos e ainda ganha desconto nas suas compras!
              </p>
            </div>

            {/* Current Prize */}
            {mainPrize && (
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="flex items-center space-x-3 mb-4">
                  <Trophy className="w-6 h-6 text-yellow-400" />
                  <span className="font-semibold text-yellow-400">Prêmio Principal - Janeiro 2024</span>
                </div>
                <h3 className="text-2xl font-bold mb-2">{mainPrize.name}</h3>
                <p className="text-gray-300 mb-3">{mainPrize.description}</p>
                <div className="text-3xl font-bold text-yellow-400">
                  {formatPrice(mainPrize.value)}
                </div>
              </div>
            )}

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-8 py-4 rounded-xl font-bold hover:from-yellow-500 hover:to-orange-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
                <Gift className="w-5 h-5" />
                <span>Participar Agora - R$ 20</span>
              </button>
              
              <button className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-black transition-all duration-300 flex items-center justify-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>Ver Regulamento</span>
              </button>
            </div>

            {/* Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8 border-t border-white/20">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2 text-green-400 mb-2">
                  <Zap className="w-5 h-5" />
                  <span className="font-bold">5% OFF</span>
                </div>
                <div className="text-sm text-gray-300">Desconto imediato nas compras</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2 text-blue-400 mb-2">
                  <Star className="w-5 h-5" />
                  <span className="font-bold">+1 Chance</span>
                </div>
                <div className="text-sm text-gray-300">A cada mês sem ganhar</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2 text-purple-400 mb-2">
                  <Gift className="w-5 h-5" />
                  <span className="font-bold">Brindes</span>
                </div>
                <div className="text-sm text-gray-300">Prêmios de consolação</div>
              </div>
            </div>
          </div>

          {/* Prize Image & Stats */}
          <div className="relative">
            <div className="relative z-10">
              {mainPrize && (
                <img 
                  src={mainPrize.image}
                  alt={mainPrize.name}
                  className="rounded-2xl shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500"
                />
              )}
            </div>
            
            {/* Floating Stats */}
            <div className="absolute -top-4 -left-4 bg-green-500 text-white px-4 py-2 rounded-full font-bold text-sm transform -rotate-12 shadow-lg">
              {raffleStats.totalParticipants} Participantes
            </div>
            
            <div className="absolute -bottom-4 -right-4 bg-yellow-500 text-black px-4 py-2 rounded-full font-bold text-sm transform rotate-12 shadow-lg">
              {raffleStats.satisfactionRate}% Satisfação
            </div>

            <div className="absolute top-1/2 -right-8 bg-purple-500 text-white px-3 py-2 rounded-full font-bold text-xs transform rotate-45 shadow-lg">
              {raffleStats.totalPrizesGiven} Prêmios Entregues
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default RaffleHero;