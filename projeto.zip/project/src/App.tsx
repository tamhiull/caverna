import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import RaffleHero from './components/RaffleHero';
import RaffleDashboard from './components/RaffleDashboard';
import RaffleResults from './components/RaffleResults';
import RaffleRules from './components/RaffleRules';
import RaffleSubscription from './components/RaffleSubscription';
import ProductCard from './components/ProductCard';
import CategoryFilter from './components/CategoryFilter';
import Cart from './components/Cart';
import Footer from './components/Footer';
import { CartProvider } from './context/CartContext';
import { products, categories } from './data/products';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isRaffleSubscriptionOpen, setIsRaffleSubscriptionOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentView, setCurrentView] = useState<'store' | 'raffle'>('raffle');

  const filteredProducts = useMemo(() => {
    let filtered = products;

    // Filter by category
    if (selectedCategory !== 'Todos') {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return filtered;
  }, [selectedCategory, searchQuery]);

  const featuredProducts = products.filter(product => product.featured);

  return (
    <CartProvider>
      <div className="min-h-screen bg-gray-50">
        <Header 
          onCartClick={() => setIsCartOpen(true)}
          onSearchChange={setSearchQuery}
        />
        
        {/* Navigation Tabs */}
        <div className="bg-white border-b sticky top-16 z-40">
          <div className="container mx-auto px-4">
            <div className="flex space-x-8">
              <button
                onClick={() => setCurrentView('raffle')}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  currentView === 'raffle'
                    ? 'border-purple-500 text-purple-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                🎲 Sistema de Rifas
              </button>
              <button
                onClick={() => setCurrentView('store')}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  currentView === 'store'
                    ? 'border-purple-500 text-purple-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                🛍️ Loja Online
              </button>
            </div>
          </div>
        </div>

        {currentView === 'raffle' ? (
          <>
            <RaffleHero />
            <RaffleDashboard />
            <RaffleResults />
            <RaffleRules />
          </>
        ) : (
          <>
            <Hero />

            {/* Featured Products */}
            <section className="container mx-auto px-4 py-16">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Produtos em Destaque
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Descubra nossa seleção especial de produtos mais populares e lançamentos exclusivos
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
                {featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </section>

            {/* All Products */}
            <section className="container mx-auto px-4 pb-16">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Todos os Produtos
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto mb-8">
                  Explore nossa coleção completa de roupas e acessórios urbanos
                </p>

                <CategoryFilter
                  categories={categories}
                  selectedCategory={selectedCategory}
                  onCategoryChange={setSelectedCategory}
                />
              </div>

              {filteredProducts.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500 text-lg">
                    Nenhum produto encontrado para "{searchQuery}" na categoria "{selectedCategory}"
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              )}
            </section>
          </>
        )}

        <Footer />

        <Cart 
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
        />

        <RaffleSubscription
          isOpen={isRaffleSubscriptionOpen}
          onClose={() => setIsRaffleSubscriptionOpen(false)}
        />

        {/* Floating Raffle Button */}
        {currentView === 'raffle' && (
          <button
            onClick={() => setIsRaffleSubscriptionOpen(true)}
            className="fixed bottom-6 right-6 bg-gradient-to-r from-purple-600 to-blue-600 text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 z-50"
          >
            <div className="flex items-center space-x-2">
              <span className="text-2xl">🎲</span>
              <span className="hidden sm:block font-semibold">Participar</span>
            </div>
          </button>
        )}
      </div>
    </CartProvider>
  );
}

export default App;